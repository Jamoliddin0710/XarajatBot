﻿using Telegram.Bot;

namespace Xarajat.Bot.Options
{
    public class XarajatBotOptions
    {
        public string BotToken { get;  set; }
    }
}